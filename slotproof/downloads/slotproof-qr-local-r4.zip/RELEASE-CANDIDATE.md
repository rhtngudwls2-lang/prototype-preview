# SlotProof QR | verified local release candidate

SlotProof compares QR payloads from the rendered final print PDF with an independent approved CSV at one-based physical page, row, and column positions. This is a completed local candidate for the supported scope, not a hosted or commercially validated service.

## Run on your PC

Extract the ZIP. From its root, run `node serve.mjs` with an existing modern Node.js runtime (verified on Node.js 24.21.0). Open it in a recent browser (verified in Edge 157.0.4341.60). Neither the app nor its local HTTP server needs a package install or Internet connection.

http://127.0.0.1:47831/
http://127.0.0.1:47831/ko/

These addresses bind only to loopback on the machine that starts the server. They are not shareable public URLs. The quickest way to try it is the first-screen matching and swapped examples: both use actual two-page vector PDFs rendered and decoded in the browser. The PDF and CSV file chooser then supports your own local input. See the bilingual guides for the physical coordinate and blank/separator rules.

## What was verified

- Final Edge regression: **34/34 PASS**, 17 GET 200 responses plus expected 404 and POST 405; zero browser errors or warnings, failed resource loads or attempted external page requests. The browser was held to loopback resource requests and all inputs were synthetic.
- The clean Cut and Stack example reads 8/8. The same-multiset swap reads 6 matches and exactly 2 mismatches: P2 R1 C2 expected 0004, found 0006; P2 R2 C1 expected 0006, found 0004. No false pass due to equal counts or sets.
- Manual file selection, required grid confirmation, CSV quoting and field order, Unicode/leading zero text, inert URL/formula payloads, exact slot statuses, empty slot and missing page, invalid PDF/header, duplicate slot, reset during a scan, and report export were measured.
- Real per-raster crop/rotation normalization at 90 and 180 degrees; variant page size and boundary crossings are held for review. Repeat values and valid blank and separator declarations work even with shuffled CSV order. A decorated separator, marked slot and damaged QR are not certified.
- Exact readable extras across multiple symbols: 4 on an undeclared page plus review, 2 on an approved blank slot, 2 on a separator, 1 outside the grid while all 8 intended slots match, and 1 beside the correct QR in an ambiguous cell plus review.
- English desktop 1280×900 and Korean 360×740 Edge viewport. The mobile proof makes each expected/found pair readable without horizontal scrolling. Keyboard skip and language switch were exercised. This is browser viewport validation, not real-phone, Safari, or assistive-technology certification.
- SEO staging verification: six title/description and canonical routes, reciprocal EN/KO/x-default alternates, 18 sitemap alternates, WebApplication structured data for the tools, and robots. The private local pages retain noindex and disallow-all robots. The fixture origin is reserved and never requested.

The current evidence is `qa/full-results-r3.json`, `qa/proof-swap.csv`, and four `qa/*.png` viewport screenshots. The old 18/25 pre-fix result is superseded and not packaged.

## Scope and privacy

Use a regular equal-cell grid with QR-only white inspection areas, a final print-visible PDF, and individually approved coordinates. The tool confirms only the supported digital raster it sees. Multiple reads in one cell, unrecognized marks, tiny or damaged symbols, and unknown geometry cannot silently pass. There is no physical barcode grade, ISO print certification, accessibility certification, PDF preflight replacement, or measured coverage on real customer jobs. No Micro QR, GS1, structured append, binary or non-UTF-8 payloads, password-protected PDF or irregular layouts. Document renderers can handle only PDF features available in the bundled browser build. Resource limits: 40 MiB PDF, 4 MiB CSV, up to 80 pages, 600 scanned slots, 16 rows and 16 columns.

Selected data stays in the tab; it is not uploaded or navigated. No jobs, cookies, trackers, vendor advertising tags, analytics, accounts or third-party requests. The renderer does not open annotations or URL payloads; the server sends loopback-only, no-store and restricted CSP headers. Rendered content and payloads are handled as data. A downloaded report remains in your files; payload cells contain JSON string literal text to protect zeros and prevent spreadsheet formulas.

No ad call or placeholder lives on the tool. No ad configuration, domain, payment, public deploy, indexing or commercial claim has been made. Advertising, if later approved, belongs only on separate content pages after usable consent and provider review; this bundle does not include an ad integration.

## Future SEO build, not enabled

By default the included HTML is local and private. `node build-pages.mjs` regenerates it without a network request. For a separately approved public origin later, set `SLOTPROOF_ORIGIN` to that exact HTTPS origin and `SLOTPROOF_BUILD_DIR` to a separate staging directory before invoking the builder. The builder blocks replacing the private `site/` HTML with indexable pages. Its staging action generates HTML, robots, and sitemap only. Before any authorized publish, include the unchanged CSS, icon, local scripts and vendor files alongside generated pages, reproduce the provided security policy, review host and indexing settings, and obtain approval. Never use the reserved test origin in production.

Optional developer QA: while `node serve.mjs` runs, set `SLOTPROOF_PLAYWRIGHT` to an existing Playwright Core package’s `index.mjs` and `SLOTPROOF_BROWSER` to an existing Chromium-family executable, then run `node qa.mjs` (requires the test artifacts and local browser, not the network to exercise the cases). Windows defaults in the test script reflect the original executor; on a different machine supply explicit paths. Ensure TEMP/TMP is in an approved writable workspace. Do not execute with a remote browser endpoint.

## Third-party licenses and pinned provenance

Browser-only assets were extracted without package installs from official free npm archives after confirming version and registry SHA-512. JavaScript and license files are included unmodified. No native canvas, CMap, fonts, WASM or unnecessary optional dependency libraries are packaged.

PDF.js / pdfjs-dist **6.5.438**, Apache-2.0. License: `site/vendor/pdfjs/LICENSE`.

https://registry.npmjs.org/pdfjs-dist/6.5.438
https://github.com/mozilla/pdf.js/releases/tag/v6.5.438

Registry SHA-512: `vg8Pw1x+AFKy4AMDvhuWl5cOYV8d698UoEANoFFhc79hqXDnZQqnOXoxw3HG907WHOg1JYOvLhP756boddFxpA==`

Browser SHA-256: `3A88402882CFA3E7E72C2C9B5149F52F0F88BAF1C5B62AA11A41ABDBC2072440`

Worker SHA-256: `1E64C8240E54735EC5913B37ACD5134747799CB8C6BB3777C70ADBC01232D2AA`

jsQR **1.4.0**, Apache-2.0. License: `site/vendor/jsqr/LICENSE`.

https://registry.npmjs.org/jsqr/1.4.0
https://github.com/cozmo/jsQR

Registry SHA-512: `dxLob7q65Xg2DvstYkRpkYtmKm2sPJ9oFhrhmudT1dZvNFFTlroai3AWSpLey/w5vMcLBXRgOJsbXpdN9HzU/A==`

Browser SHA-256: `BC40C8A15196236B2314DB0856F72CA0B49980CD5413B8C852A7349F5FEE0859`

QR and PDF fixtures are generated in-project with inert text; there are no production files, private inputs or third-party images in the archive.
