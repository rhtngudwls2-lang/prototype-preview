import {createServer} from "node:http";
import {readFile,stat} from "node:fs/promises";
import {fileURLToPath} from "node:url";
import path from "node:path";
import {createHash} from "node:crypto";
const root=fileURLToPath(new URL("./site/",import.meta.url));
const mime={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".mjs":"text/javascript; charset=utf-8",".js":"text/javascript; charset=utf-8",".svg":"image/svg+xml",".xml":"application/xml; charset=utf-8",".txt":"text/plain; charset=utf-8",".csv":"text/csv; charset=utf-8",".pdf":"application/pdf",".zip":"application/zip"};
const p=Number(process.env.PORT||47831);
if(!Number.isInteger(p)||p<1024||p>65535)throw Error("Invalid port");
const csp=(hash="")=>"default-src 'none'; script-src 'self'"+hash+"; style-src 'self'; img-src 'self' blob: data:; connect-src 'none'; worker-src 'self'; font-src 'none'; frame-ancestors 'none'; form-action 'none'; base-uri 'none'; object-src 'none'; manifest-src 'none'; media-src 'none'";
const server=createServer(async(req,res)=>{
  const header=(type,hash="")=>{
    res.setHeader("Content-Type",type);
    res.setHeader("Content-Security-Policy",csp(hash));
    res.setHeader("Referrer-Policy","no-referrer");
    res.setHeader("X-Content-Type-Options","nosniff");
    res.setHeader("X-Frame-Options","DENY");
    res.setHeader("Cache-Control","no-store");
    res.setHeader("Permissions-Policy","camera=(), microphone=(), geolocation=(), payment=()");
    res.setHeader("Cross-Origin-Resource-Policy","same-origin");
  };
  const send=(code,msg)=>{header("text/plain; charset=utf-8");res.writeHead(code);res.end(req.method==="HEAD"?undefined:msg);};
  if(!["GET","HEAD"].includes(req.method)){res.setHeader("Allow","GET, HEAD");return send(405,"Method not allowed");}
  if(!["127.0.0.1:"+p,"localhost:"+p].includes(req.headers.host))return send(400,"Loopback host required");
  try{
    const u=new URL(req.url,"http://127.0.0.1:"+p);
    const pathname=decodeURIComponent(u.pathname);
    if(!/^\/[A-Za-z0-9._/-]*$/.test(pathname)||pathname.split("/").some(s=>s.startsWith(".")))return send(400,"Invalid path");
    let file=path.resolve(root,"."+pathname);
    if(!file.toLowerCase().startsWith(root.toLowerCase())&&file!==path.normalize(root).slice(0,-1))return send(404,"Not found");
    if((await stat(file)).isDirectory())file=path.join(file,"index.html");
    const ext=path.extname(file);
    if(!mime[ext])return send(404,"Not found");
    const data=await readFile(file);
    const json=ext===".html"?data.toString().match(/<script type="application\/ld\+json">([^<]*)<\/script>/u)?.[1]:null;
    header(mime[ext],json?" 'sha256-"+createHash("sha256").update(json).digest("base64")+"'":"");
    if(ext===".zip")res.setHeader("Content-Disposition","attachment; filename="+JSON.stringify(path.basename(file)));
    res.writeHead(200);res.end(req.method==="HEAD"?undefined:data);
  }catch(e){send(e instanceof URIError?400:404,"Not found");}
});
server.on("error",e=>{console.error(e.message);process.exitCode=1;});
server.listen(p,"127.0.0.1",()=>console.log("SlotProof local preview: http://127.0.0.1:"+p+"/"));
